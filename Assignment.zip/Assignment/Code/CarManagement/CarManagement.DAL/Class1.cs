﻿namespace CarManagement.DAL
{
    public class Class1
    {

    }
}
