﻿using CarManagement.Entity.Models;

namespace CarManagement.DAL.Interface
{
    public interface ICarService
    {
        int AddCar(Car car);  
        List<CarDto> GetAllCars(string searchTerm = null);  
        Car GetCarById(int modelId);  
    }
}
