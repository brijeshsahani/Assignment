﻿using CarManagement.Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.DAL.Interface
{
    public interface ISalesCommissionService
    {
        List<SalesCommissionRecord> GetSalesCommissionRecords();
    }
}
