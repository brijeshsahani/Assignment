﻿using CarManagement.Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.DAL.Interface
{
    public interface IAuthService
    {
        LoginResult LoginUser(string email, string password);
    }
}
