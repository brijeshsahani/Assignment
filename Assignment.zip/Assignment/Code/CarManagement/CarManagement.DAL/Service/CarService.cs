﻿using CarManagement.DAL.Interface;
using CarManagement.Entity.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CarManagement.DAL.Service
{
    public class CarService : ICarService
    {
        private readonly string _connectionString;

        public CarService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("db");
        }

        public int AddCar(Car car)
        {
            int modelId;
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string query = "INSERT INTO CarTbl (Brand, Class, ModelName, ModelCode, Description, Features, Price, DateOfManufacturing, Active, SortOrder) " +
                               "OUTPUT INSERTED.ModelID " +
                               "VALUES (@Brand, @Class, @ModelName, @ModelCode, @Description, @Features, @Price, @DateOfManufacturing, @Active, " +
                               "(SELECT COALESCE(MAX(SortOrder), 0) + 1 FROM CarTbl))";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Brand", car.Brand);
                cmd.Parameters.AddWithValue("@Class", car.Class);
                cmd.Parameters.AddWithValue("@ModelName", car.ModelName);
                cmd.Parameters.AddWithValue("@ModelCode", car.ModelCode);
                cmd.Parameters.AddWithValue("@Description", car.Description);
                cmd.Parameters.AddWithValue("@Features", car.Features);
                cmd.Parameters.AddWithValue("@Price", car.Price);
                cmd.Parameters.AddWithValue("@DateOfManufacturing", car.DateOfManufacturing);
                cmd.Parameters.AddWithValue("@Active", car.Active);
                //cmd.Parameters.AddWithValue("@SortOrder", car.SortOrder);

                conn.Open();
                modelId = (int)cmd.ExecuteScalar();
            }

            if (car.ImagePaths != null && car.ImagePaths.Count > 0)
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    string query = "INSERT INTO CarImageTbl (ModelID, ImagePath) VALUES (@ModelID, @ImagePath)";
                    foreach (var imagePath in car.ImagePaths)
                    {
                        SqlCommand cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@ModelID", modelId);
                        cmd.Parameters.AddWithValue("@ImagePath", imagePath);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                }
            }

            return modelId;
        }

        public List<CarDto> GetAllCars(string searchTerm = null)
        {
            List<CarDto> cars = new List<CarDto>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sqlQuery = @"
                        WITH [CarImage] AS (
                            SELECT  [CarImageTbl].[ImageID],
                                    [CarImageTbl].[ImagePath],
                                    [CarImageTbl].[ModelID],
                                    ROW_NUMBER() OVER(PARTITION BY [ModelID] ORDER BY [ImageID]) AS RowNumber
                            FROM [dbo].[CarImageTbl]
                        )
                        SELECT [CarTbl].[Brand],
                               [CarTbl].[Class],
                               [CarImage].[ImagePath],
                               [CarTbl].[ModelID],
                               [CarTbl].[ModelName],
                               [CarTbl].[ModelCode]
                        FROM [dbo].[CarTbl]
                            INNER JOIN [CarImage]
                                ON [CarTbl].[ModelID] = [CarImage].[ModelID]
                        WHERE [CarImage].[RowNumber] = 1
                            AND [CarTbl].[Active] = 1";

                if (!string.IsNullOrEmpty(searchTerm))
                {
                    sqlQuery += " AND (ModelName LIKE @SearchTerm OR ModelCode LIKE @SearchTerm)";
                }

                sqlQuery += " ORDER BY DateOfManufacturing DESC, SortOrder DESC"; 

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                if (!string.IsNullOrEmpty(searchTerm))
                {
                    cmd.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");
                }

                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cars.Add(new CarDto
                        {
                            Brand = reader.GetString(0),
                            Class = reader.GetString(1),
                            ImagePaths = reader.GetString(2), 
                            ModelID = reader.GetInt32(3),
                            ModelName = reader.GetString(4),
                            ModelCode = reader.GetString(5)
                        });
                    }
                }
            }
            return cars;
        }

        public Car GetCarById(int modelId)
        {
            Car car = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sqlQuery = @"
                            SELECT 
                                  [ModelID],
                                  [Brand],
                                  [Class],
                                  [ModelName],
                                  [ModelCode],
                                  [Description],
                                  [Features],
                                  [Price],
                                  [DateOfManufacturing],
                                  [Active],
                                  [SortOrder]
                            FROM [CoreEshDB].[dbo].[CarTbl]
                            WHERE ModelID = @ModelID
                ";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.AddWithValue("@ModelID", modelId);
                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        car = new Car
                        {
                            ModelID = reader.GetInt32(0),
                            Brand = reader.GetString(1),
                            Class = reader.GetString(2),
                            ModelName = reader.GetString(3),
                            ModelCode = reader.GetString(4),
                            Description = reader.GetString(5),
                            Features = reader.GetString(6),
                            Price = reader.GetDecimal(7),
                            DateOfManufacturing = reader.GetDateTime(8),
                            Active = reader.GetBoolean(9),
                            //SortOrder = reader.GetInt32(10),
                            ImagePaths = new List<string>() // Initialize image paths list
                        };
                    }
                }
            }

            // Retrieve the images for this car
            if (car != null)
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    string query = "SELECT ImagePath FROM CarImageTbl WHERE ModelID = @ModelID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ModelID", modelId);
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            car.ImagePaths.Add(reader.GetString(0));
                        }
                    }
                }
            }

            return car;
        }
    }
}
