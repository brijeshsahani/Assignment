﻿using CarManagement.DAL.Interface;
using CarManagement.Entity.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManagement.DAL.Service
{
    public class SalesCommissionService: ISalesCommissionService
    {
        private readonly string _connectionString;

        public SalesCommissionService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("db");
        }
        public List<SalesCommissionRecord> GetSalesCommissionRecords()
        {
            List<SalesCommissionRecord> records = new List<SalesCommissionRecord>();

            string query = @"
            SELECT 
                sr.Salesman,
                sr.Class,
                (sr.Cars_Sold_Audi * cc.Fixed_Commission) AS Audi_Commission,
                (sr.Cars_Sold_Jaguar * cc.Fixed_Commission) AS Jaguar_Commission,
                (sr.Cars_Sold_LandRover * cc.Fixed_Commission) AS LandRover_Commission,
                (sr.Cars_Sold_Renault * cc.Fixed_Commission) AS Renault_Commission,
                (CASE 
                    WHEN sr.Class = 'A' THEN sr.Cars_Sold_Audi * cc.Class_A_Commission / 100
                    WHEN sr.Class = 'B' THEN sr.Cars_Sold_Jaguar * cc.Class_B_Commission / 100
                    ELSE sr.Cars_Sold_Renault * cc.Class_C_Commission / 100 
                 END) AS Class_Wise_Commission,
                (CASE 
                    WHEN spys.Last_Year_Sales_Amount > 500000 AND sr.Class = 'A' THEN 
                        (sr.Cars_Sold_Audi * cc.Class_A_Commission / 100) * 0.02
                    ELSE 0 
                END) AS Additional_Commission_2_Percent,
                (sr.Cars_Sold_Audi * cc.Fixed_Commission + 
                 sr.Cars_Sold_Jaguar * cc.Fixed_Commission + 
                 sr.Cars_Sold_LandRover * cc.Fixed_Commission + 
                 sr.Cars_Sold_Renault * cc.Fixed_Commission + 
                 (CASE 
                    WHEN sr.Class = 'A' THEN sr.Cars_Sold_Audi * cc.Class_A_Commission / 100
                    WHEN sr.Class = 'B' THEN sr.Cars_Sold_Jaguar * cc.Class_B_Commission / 100
                    ELSE sr.Cars_Sold_Renault * cc.Class_C_Commission / 100 
                 END) + 
                 (CASE 
                    WHEN spys.Last_Year_Sales_Amount > 500000 AND sr.Class = 'A' THEN 
                        (sr.Cars_Sold_Audi * cc.Class_A_Commission / 100) * 0.02
                    ELSE 0 
                 END)) AS Total_Commission
            FROM 
                Sales_Report sr
            JOIN 
                Car_Commission cc ON 
                (sr.Cars_Sold_Audi > 0 AND cc.Brand = 'Audi') OR
                (sr.Cars_Sold_Jaguar > 0 AND cc.Brand = 'Jaguar') OR
                (sr.Cars_Sold_LandRover > 0 AND cc.Brand = 'Land Rover') OR
                (sr.Cars_Sold_Renault > 0 AND cc.Brand = 'Renault')
            JOIN 
                Salesman_Previous_Year_Sales spys ON 
                sr.Salesman = spys.Salesman_Name
            ORDER BY 
                sr.Salesman, sr.Class;";

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            records.Add(new SalesCommissionRecord
                            {
                                Salesman = reader["Salesman"].ToString(),
                                Class = reader["Class"].ToString(),
                                AudiCommission = Convert.ToDecimal(reader["Audi_Commission"]),
                                JaguarCommission = Convert.ToDecimal(reader["Jaguar_Commission"]),
                                LandRoverCommission = Convert.ToDecimal(reader["LandRover_Commission"]),
                                RenaultCommission = Convert.ToDecimal(reader["Renault_Commission"]),
                                ClassWiseCommission = Convert.ToDecimal(reader["Class_Wise_Commission"]),
                                AdditionalCommission2Percent = Convert.ToDecimal(reader["Additional_Commission_2_Percent"]),
                                TotalCommission = Convert.ToDecimal(reader["Total_Commission"])
                            });
                        }
                    }
                }
            }

            return records;
        }
    }
}
