﻿using CarManagement.DAL.Interface;
using CarManagement.Entity.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace CarManagement.DAL.Service
{
    public class AuthService : IAuthService
    {
        private readonly string _connectionString;

        public AuthService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("db");
        }
        public LoginResult LoginUser(string email, string password)
        {
            LoginResult loginResult = new LoginResult();

          

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    string sqlQuery = @"SELECT u.UserId, u.Email, r.RoleName
                                    FROM Users u
                                    INNER JOIN Roles r ON u.RoleId = r.RoleId
                                    WHERE u.Email = @Email AND u.Password = @Password"; 

                    SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Password", password); 

                     conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while ( reader.Read())
                        {
                            loginResult.IsSuccess = true;
                            loginResult.UserId = Convert.ToInt32(reader["UserId"]);
                            loginResult.Email = reader["Email"].ToString();
                            loginResult.RoleName = reader["RoleName"].ToString();
                        }
                    }
                    else
                    {
                        loginResult.IsSuccess = false;
                        loginResult.ErrorMessage = "Invalid login credentials.";
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                loginResult.IsSuccess = false;
                loginResult.ErrorMessage = "Error: " + ex.Message;
            }

            return loginResult;
        }
    }
}
