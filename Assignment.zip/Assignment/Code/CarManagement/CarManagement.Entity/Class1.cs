﻿namespace CarManagement.Entity
{
    public class Class1
    {

    }
}
