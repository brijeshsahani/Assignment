﻿namespace CarManagement.Entity.Models
{
    public class SalesCommissionRecord
    {
        public string Salesman { get; set; }
        public string Class { get; set; }
        public decimal AudiCommission { get; set; }
        public decimal JaguarCommission { get; set; }
        public decimal LandRoverCommission { get; set; }
        public decimal RenaultCommission { get; set; }
        public decimal ClassWiseCommission { get; set; }
        public decimal AdditionalCommission2Percent { get; set; }
        public decimal TotalCommission { get; set; }
    }
}
