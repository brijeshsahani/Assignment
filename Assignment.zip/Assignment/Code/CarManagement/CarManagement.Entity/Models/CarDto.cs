﻿namespace CarManagement.Entity.Models
{
    public class CarDto
    {
        public int ModelID { get; set; }
        public string Brand { get; set; }
        public string Class { get; set; }
        public string ModelName { get; set; }
        public string ModelCode { get; set; }
        public string ImagePaths { get; set; } 
    }
}
