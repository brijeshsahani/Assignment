﻿using Microsoft.AspNetCore.Mvc;

namespace CarManagement.Web.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }
    }
}
