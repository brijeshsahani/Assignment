
var ApiUrl = "https://localhost:7279";

(function () {
    var Core = {};
    window.Core = window.Core || {};
    window.Core = $.extend(window.Core, Core);
})();

(function (v) {
    var StoreManager = function () {
        this.get = function (key) {
            return JSON.parse(instance.get(key));
        };
        this.set = function (key, data) {
            instance.set(key, JSON.stringify(data));
        };
        this.remove = function (key) {
            instance.remove(key);
        };
        this.clear = function () {
            instance.clear();
        };

        var SessionStorage = function () {
            this.get = function (key) {
                return sessionStorage.getItem(key);
            };
            this.set = function (key, data) {
                sessionStorage.setItem(key, data);
            };
            this.remove = function (key) {
                sessionStorage.removeItem(key);
            };
            this.clear = function () {
                sessionStorage.clear();
            };
        };
      

        var LocalStore = function () {
            this.get = function (key) {
                return localStorage.getItem(key);
            };
            this.set = function (key, data) {
                localStorage.setItem(key, data);
            };
            this.remove = function (key) {
                localStorage.removeItem(key);
            };
            this.clear = function () {
                localStorage.clear();
            };
        };

        var instance = new SessionStorage();
    };
    v.store = new StoreManager();
})(window.Core);

(function () {

    $.ajaxSetup({
        
        beforeSend: function (xhr) {
            debugger;
            var role = Core.store.get("Role")
            if (role != undefined && role != "") {
                xhr.setRequestHeader('role', role);
            }

        }
    });

})();
