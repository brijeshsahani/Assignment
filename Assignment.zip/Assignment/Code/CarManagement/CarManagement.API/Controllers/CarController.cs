﻿using CarManagement.API.Filters;
using CarManagement.DAL.Interface;
using CarManagement.Entity.Models;
using Microsoft.AspNetCore.Mvc;

namespace CarManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private readonly ICarService _carService;

        public CarController(ICarService carService)
        {
            _carService = carService;
        }

        [Authorize("Admin")]
        [HttpPost("AddCar")]
        public IActionResult AddCar([FromForm] Car car)
        {
            List<string> imagePaths = new List<string>();
         
            if (car.Images != null && car.Images.Count > 0)
            {
                foreach (var image in car.Images)
                {
                    if (image.Length > 0)
                    {
                        string uniqueFileName = $"{Guid.NewGuid()}_{image.FileName}";

                        var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", uniqueFileName);

                        var directory = Path.GetDirectoryName(filePath);
                        if (!Directory.Exists(directory))
                        {
                            Directory.CreateDirectory(directory);
                        }

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            image.CopyTo(stream);
                        }

                        imagePaths.Add($"/images/{uniqueFileName}");
                    }
                }
            }

            car.ImagePaths = imagePaths;

            int newId = _carService.AddCar(car);

            return Ok(new { ModelID = newId, Message = "Car added successfully!" });
        }

        [Authorize("Admin", "User")]
        [HttpGet("GetAllCars")]
        public IActionResult GetAllCars([FromQuery] string searchText = "")
        {
            return Ok(_carService.GetAllCars(searchText));
        }

        [Authorize("Admin", "User")]
        [HttpGet("GetCarById")]
        public IActionResult GetCarById([FromQuery] int id)
        {
            var car = _carService.GetCarById(id);
            if (car == null) return NotFound("Car not found!");
            return Ok(car);
        }

    }
}
