﻿using CarManagement.API.Filters;
using CarManagement.DAL.Interface;
using CarManagement.DAL.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CarManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesCommissionController : ControllerBase
    {
        private readonly ISalesCommissionService _salesCommissionService;

        public SalesCommissionController(ISalesCommissionService salesCommissionService)
        {
            _salesCommissionService = salesCommissionService;
        }

        [Authorize("Admin")]
        [HttpGet("GetSalesCommission")]
        public IActionResult GetSalesCommission()
        {
            return Ok(_salesCommissionService.GetSalesCommissionRecords());
        }
    }
}
