﻿using CarManagement.Entity.Models;
using Microsoft.AspNetCore.Mvc;
using CarManagement.DAL.Interface;
using Newtonsoft.Json;

namespace CarManagement.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest loginRequest)
        {
            if (loginRequest == null)
            {
                return BadRequest("Invalid input data.");
            }

            var result =  _authService.LoginUser(loginRequest.Email, loginRequest.Password);

            if (result.IsSuccess)
            {
                return Ok(new
                {
                    UserId = result.UserId,
                    Email = result.Email,
                    RoleName = result.RoleName
                });
            }

            return Unauthorized(result.ErrorMessage);
        }
    }
}
