﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CarManagement.API.Filters
{
    public class AuthorizeAttribute : ActionFilterAttribute
    {
        private readonly string[] _allowedRoles;

        public AuthorizeAttribute(params string[] allowedRoles)
        {
            _allowedRoles = allowedRoles;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var role = context.HttpContext.Request.Headers["Role"].ToString();

            if (string.IsNullOrEmpty(role))
            {
                context.Result = new ObjectResult(new { message = "Access Denied" }) { StatusCode = 403 };
                return;
            }

            if (string.IsNullOrEmpty(role) || !_allowedRoles.Contains(role))
            {
                context.Result = new ObjectResult(new { message = "Access Denied" }) { StatusCode = 403 };
            }

            base.OnActionExecuting(context);
        }
    }

}
